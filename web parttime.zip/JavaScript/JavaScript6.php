<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>JavaScript Can Show HTML Elements</title>
</head>

<body>
	
	<h2>What Can JavaScript Do?</h2>
<p>JavaScript can show hidden HTML elements.</p>
	
	
	<p id="demo" style="display: none">Hellow JavaScript</p>
	
	<button type="button" onClick="document.getElementById('demo').style.display='block'">Click Me!
		
	</button>
	
</body>
</html>