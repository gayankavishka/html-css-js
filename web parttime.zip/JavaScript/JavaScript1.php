<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>First Java Script</title>
</head>

<body>
	
	<h1 id="demo"></h1>
	
	<script>
	
		document.getElementById("demo").innerHTML = "Hellow JavaSctipt";
		document.write("<h1>Hellow World</h1>");
		
		
	</script>

</body>
</html>