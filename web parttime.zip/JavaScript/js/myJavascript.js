document.write(text);
document.getElementById("demo").innerHTML = "Hellow JavaScript";