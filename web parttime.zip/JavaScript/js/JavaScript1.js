document.write("<h1><center>WEB<center></h1>");

document.write("<p><font color=blue>Learn JavaScript in a day</font><p>");