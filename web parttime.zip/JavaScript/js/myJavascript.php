<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="myjavascript.js">
    <title>Document</title>
</head>
<body>


<h2>What Can JavaScript Do?</h2>
<p>JavaScript can change HTML attribute values.</p>
<p>In this case JavaScript changes the value of the src (source) 
attribute of an image.</p>
<button
onclick="document.getElementById('myImage').src='image/pic_bulbon.gif'">Turn 
on the light</button>
<img id="myImage" src="image/pic_bulboff.gif" style="width:100px">
<button
onclick="document.getElementById('myImage').src='image/pic_bulboff.gif'">Turn 
off the light</button>


</body>
</html>