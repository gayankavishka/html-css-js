<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>My First Web Page</h1>
    <p>My First paragraph</p>
    <p id="demo"></p>

    <button type="button" onclick="document.write(5 +8)">Try it</button>
    

    <script>
        document.write(10 + 15);
        window.alert(4 +9); //window alert
        alert(12 +67); //alert box
        console.log(5 + 95); //console log
    </script>

</body>
</html>