<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>JavaScript Change HTML Styles</title>
</head>

<body>

	<h2>What Can JavaScript Do?</h2>
<p id="demo">JavaScript can change the style of an HTML element.</p>
	
	<button type="button" onClick="document.getElementById('demo').style.fontSize='45px'">Click Me!
	
	</button>
	
	
</body>
</html>