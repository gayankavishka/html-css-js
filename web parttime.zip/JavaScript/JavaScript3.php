<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>JS Change HTML Attributes</title>
</head>

	
<body>
	<h2>What Can JavaScript Do?</h2>
<p>JavaScript can change HTML attribute values.</p>
<p>In this case JavaScript changes the value of the src (source) 
attribute of an image.</p>
	
	<button onClick="document.getElementById('myImage').src='image/pic_bulbon.gif'">Turn On the light</button>
	
	<img id="myImage" src="image/pic_bulboff.gif" style="width:100px">
	
	<button onClick="document.getElementbyId('myImage').src='image/pic_bulboff.gif'">Turn off the light</button>
	
	
	
</body>
</html>