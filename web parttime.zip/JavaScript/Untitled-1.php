<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	
	<h1>this is JavaScript</h1>
	<button document.getElementById("demo").innerHTML = "Hello JavaScript";>click here</button>
	
</body>
</html>