<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>JavaScript Where To</title>
</head>

<body>
	
	<h2>JavaScript in Body</h2>
	
	<p id="demo"></p>
	
	<script>
		
		document.getElementById("demo").innerHTML = "My First JavaProject";
		
	</script>
	
	
</body>
</html>