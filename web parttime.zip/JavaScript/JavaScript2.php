<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	
	<h2>What Can JavaScript Do?</h2>

<p id="demo">JavaScript can change HTML content.</p>

<button type="button" onClick='document.getElementById("demo").innerHTML
							   = "Hellow JavaScript!"'>Click Me!</button>
	
	
</body>
</html>